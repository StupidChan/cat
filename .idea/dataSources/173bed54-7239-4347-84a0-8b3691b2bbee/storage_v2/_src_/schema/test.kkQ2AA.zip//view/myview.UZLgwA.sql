create view myview as
select concat(`test`.`person`.`FirstName`, `test`.`person`.`LastName`) AS `MyName`,
       `test`.`person`.`Email`                                         AS `Email`
from `test`.`person`
where (`test`.`person`.`PersonId` < 5);

